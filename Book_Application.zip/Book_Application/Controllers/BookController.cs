﻿using Book_Application.DAL;
using Book_Application.Models;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Book_Application.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        DALc dal = new DALc();
        public BookController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet("GetSortedByPublisher")]
        [Produces("application/json")]
        public IEnumerable<BookResponse> GetSortedByPublisher()       
        {
            return GetBookDetails().Select(a => new BookResponse { Publisher = a.Publisher, AuthorLastName = a.AuthorLastName, AuthorFirstName = a.AuthorFirstName, Title = a.Title, Price = a.Price }).OrderBy(b => b.Publisher).ThenBy(c => (c.AuthorLastName + "," + c.AuthorFirstName)).ThenBy(d => d.Title);
        }

        [HttpGet("GetSortedByAuthor")]
        [Produces("application/json")]
        public IEnumerable<BookResponse> GetSortedByAuthor()
        {
            return GetBookDetails().Select(a => new BookResponse { Publisher = a.Publisher, AuthorLastName = a.AuthorLastName, AuthorFirstName = a.AuthorFirstName, Title = a.Title, Price = a.Price }).OrderBy(a => (a.AuthorLastName + "," + a.AuthorFirstName)).ThenBy(b => b.Title);
        }

        [HttpGet("MLA")]
        [Produces("application/json")]
        public List<MLAResponse> GetMLA()
        {
            return GetMLATestData().ToList().Select(a => new MLAResponse
            {
                MLA = a.AuthorLastName + "," + a.AuthorFirstName + "." + "\"" + a.TitleOfSource + "?" + "\"" + "," + a.Publisher + "," + a.PublicationDate + "," + a.Location
            })
        .ToList();
        }

        [HttpGet("CSM")]
        [Produces("application/json")]
        public List<CMSResponse> GetCSM()
        {
            return GetCSMTestData().ToList().Select(a => new CMSResponse
            {
                CSM = a.AuthorLastName + "," + a.AuthorFirstName + "." + "\"" + a.JournalTitle + "\"" + "," + a.VolumeNo + "(" + a.IssueNo + "):" + a.PageRange +"." + a.URL_DOI
            })
        .ToList();
        }

        [HttpGet("GetSortedByPublisherWithSP")]
        [Produces("application/json")]
        public IEnumerable<BookResponse> GetSortedByPublisherWithSP()
        {
            List<BookResponse> bookResponses = new List<BookResponse>();
            try
            {
                dal = new DALc();
                DataTable dt = new DataTable();
                dt = dal.DALBookDetails(_configuration.GetConnectionString("DefaultConnection"), "PUBLISHER");
                if (dt != null && dt.Rows.Count > 0)
                {
                    bookResponses = (from DataRow BK in dt.Rows
                                     select new BookResponse
                                     {
                                         Publisher = BK["Publisher"].ToString(),
                                         AuthorFirstName = BK["AuthorFirstName"].ToString(),
                                         AuthorLastName = BK["AuthorLastName"].ToString(),
                                         Price = Convert.ToDecimal(BK["Price"].ToString()),
                                         Title = BK["Title"].ToString(),
                                     }
                                     ).ToList();
                }
                return bookResponses;
            }
            catch(Exception Ex)
            {
                return bookResponses;
            }
        }

        [HttpGet("GetSortedByAuthorWithSP")]
        [Produces("application/json")]
        public IEnumerable<BookResponse> GetSortedByAuthorWithSP()
        {
            List<BookResponse> bookResponses = new List<BookResponse>();
            try
            {
                dal = new DALc();
                DataTable dt = new DataTable();
                dt = dal.DALBookDetails(_configuration.GetConnectionString("DefaultConnection"), "AUTHOR");
                if (dt != null && dt.Rows.Count > 0)
                {
                    bookResponses = (from DataRow BK in dt.Rows
                                     select new BookResponse
                                     {
                                         Publisher = BK["Publisher"].ToString(),
                                         AuthorFirstName = BK["AuthorFirstName"].ToString(),
                                         AuthorLastName = BK["AuthorLastName"].ToString(),
                                         Price = Convert.ToDecimal(BK["Price"].ToString()),
                                         Title = BK["Title"].ToString(),
                                     }
                                     ).ToList();
                }
                return bookResponses;
            }
            catch (Exception Ex)
            {
                return bookResponses;
            }
        }

        [HttpGet("GetTotalPrice")]
        public string GetTotalPrice()
        {
            decimal totalPrice = 0;
            try
            {
                dal = new DALc();
                DataTable dt = new DataTable();
                dt = dal.DALBookDetails(_configuration.GetConnectionString("DefaultConnection"), "PRICE");
                if (dt != null && dt.Rows.Count > 0)
                {
                    totalPrice = Convert.ToDecimal(dt.Rows[0]["TotalPrice"].ToString());
                }
                return "The total price is " + totalPrice;
            }
            catch (Exception Ex)
            {
                return Ex.Message;
            }
        }

        [HttpPost("UploadLargeList")]
        public string PostFile(IFormFile uploadedFile)
        {
            try
            {
                if (uploadedFile !=null && uploadedFile.FileName.EndsWith(".xlsx"))
                {
                    dal = new DALc();
                    using (XLWorkbook workBook = new XLWorkbook(uploadedFile.OpenReadStream()))
                    {
                        IXLWorksheet workSheet = workBook.Worksheet(1);

                        DataTable dt = new DataTable();

                        bool firstRow = true;
                        foreach (IXLRow row in workSheet.Rows())
                        {
                            if (firstRow)
                            {
                                foreach (IXLCell cell in row.Cells())
                                {
                                    dt.Columns.Add(cell.Value.ToString());
                                }
                                firstRow = false;
                            }
                            else
                            {
                                dt.Rows.Add();
                                int i = 0;

                                foreach (IXLCell cell in row.Cells(row.FirstCellUsed().Address.ColumnNumber, row.LastCellUsed().Address.ColumnNumber))
                                {
                                    dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
                                    i++;
                                }
                            }
                        }

                        if (dt != null && dt.Rows.Count > 0)
                        {
                            return dal.BulkInsert(_configuration.GetConnectionString("DefaultConnection"), dt);
                        }
                    }
                    return "Something went Wrong";
                }
                else
                {
                    return "Please choose the Excel file (.xlsx)";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private List<Book> GetBookDetails()
        {
            return new List<Book>()
        {
            new Book()
            {
                Publisher  = "Balaji",
                Title = "Book Assessment",
                AuthorLastName  = "Balaji",
                AuthorFirstName  ="SS",
                Price = 100
            },
            new Book()
            {
                Publisher  = "AMadhan",
                Title = "Home Assessment",
                AuthorLastName  = "Mahendran",
                AuthorFirstName  ="Madhan",
                Price = 120
            },
            new Book()
            {
                Publisher  = "Balaji",
                Title = "Home Assessment",
                AuthorLastName  = "Ashok",
                AuthorFirstName  ="Kumar",
                Price = 150
            }
        };
        }

        private List<Book> GetMLATestData()
        {
            return new List<Book>()
        {
            new Book()
            {
                Publisher  = "Balaji",
                Title = "Book Assessment",
                AuthorLastName  = "Balaji",
                AuthorFirstName  ="SS",
                Price = 100,
                TitleOfSource = "Behind the Blue Pencil:Censorship",
                TitleOfContainer = "On Writing",
                PublicationDate = "1996",
                Location = "pp. 120-126"
            },
            new Book()
            {
                Publisher  = "AMadhan",
                Title = "Home Assessment",
                AuthorLastName  = "Mahendran",
                AuthorFirstName  ="Madhan",
                Price = 120,
                TitleOfSource = "Behind the Blue Pen",
                TitleOfContainer = "On Reading",
                PublicationDate = "1996",
                Location = "pp. 10-40"
            },
            new Book()
            {
                Publisher  = "Balaji",
                Title = "Home Assessment",
                AuthorLastName  = "Ashok",
                AuthorFirstName  ="Kumar",
                Price = 150,
                TitleOfSource = "Colour Pencil",
                TitleOfContainer = "On Checking",
                PublicationDate = "1967",
                Location = "pp. 1440-1446"
            }
        };
        }

        private List<Book> GetCSMTestData()
        {
            return new List<Book>()
        {
            new Book()
            {
                AuthorLastName  = "Balaji",
                AuthorFirstName  ="SS",
                Price = 100,
                JournalTitle = "Myster of a talking wombat",
                VolumeNo ="No.2",
                IssueNo = "February 1935",
                PageRange = "275-380",
                URL_DOI = "https://images.app.goo.gl/"
            },
            new Book()
            {
                AuthorLastName  = "Mahendran",
                AuthorFirstName  ="Madhan",
                Price = 120,
                JournalTitle = "Clinical Reviews and Opinions",
                VolumeNo ="No.2",
                IssueNo = "Jan 1935",
                PageRange = "300-330",
                URL_DOI = "https://images.app.goo.gl/"
            },
            new Book()
            {
                AuthorLastName  = "Ashok",
                AuthorFirstName  ="Kumar",
                Price = 150,
                JournalTitle = "African Journal of Food Science",
                VolumeNo ="No.4",
                IssueNo = "March 1935",
                PageRange = "600-650",
                URL_DOI = "https://images.app.goo.gl/"
            }
        };
        }


    }
}
