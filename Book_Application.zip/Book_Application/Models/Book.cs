﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Book_Application.Models
{
    public class Book
    {
        public string Publisher { get; set; }
        public string Title { get; set; }
        public string AuthorLastName { get; set; }
        public string AuthorFirstName { get; set; }
        public decimal Price { get; set; }
        public string TitleOfSource { get; set; }
        public string TitleOfContainer { get; set; }
        public string PublicationDate { get; set; }
        public string Location { get; set; }
        public string JournalTitle { get; set; }
        public string VolumeNo { get; set; }
        public string IssueNo { get; set; }
        public string PageRange { get; set; }
        public string URL_DOI { get; set; }
    }

    public class BookResponse
    {
        public string Publisher { get; set; }
        public string Title { get; set; }
        public string AuthorLastName { get; set; }
        public string AuthorFirstName { get; set; }
        public decimal Price { get; set; }

    }
    public class MLAResponse
    {
        public string MLA { get; set; }
    }
    public class CMSResponse
    {
        public string CSM { get; set; }
    }
}
